﻿using UnityEngine;
using System.Collections;

public class BulletPattern1 : MonoBehaviour 
{
	public GameObject bullet;
	public bool shootable = true;
	public float delta;

	// Use this for initialization
	void Start () 
	{

	}
	
	// Update is called once per frame
	void FixedUpdate () 
	{
		ShootingBullet ();
	}

	void ShootingBullet()
	{
		if (shootable) 
		{
			StartCoroutine ("MakeBullet");
		}
	}

	IEnumerator MakeBullet()
	{	
		delta = 7;
		shootable = false;
		bullet.GetComponent<Pattern1>().angle += delta;
		Instantiate (bullet);

		yield return new WaitForSeconds(0.004f);
		shootable = true;
	}
}
