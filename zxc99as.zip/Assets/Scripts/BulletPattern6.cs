﻿using UnityEngine;
using System.Collections;

public class BulletPattern6 : MonoBehaviour 
{

	public GameObject bullet;
	public GameObject player;
	public bool shootable = true;
	public float delta;

	// Use this for initialization
	void Start () 
	{
		player = GameObject.FindGameObjectWithTag ("Player");
	}
	
	void FixedUpdate () 
	{
		ShootingBullet ();
	}
	
	void ShootingBullet()
	{
		if (shootable) 
		{
			StartCoroutine ("MakeBullet");
		}
	}
	
	IEnumerator MakeBullet()
	{	
		shootable = false;
		delta = Mathf.Atan2 (transform.position.y - player.transform.position.y, transform.position.x - player.transform.position.x);
		delta *= 57.295779513f;

		bullet.GetComponent<Pattern1> ().number = 5;
		bullet.GetComponent<Pattern1> ().angle = delta;
		Instantiate (bullet);

		yield return new WaitForSeconds(0.8f);
		shootable = true;
	}
}
