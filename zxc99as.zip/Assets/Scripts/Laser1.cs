﻿using UnityEngine;
using System.Collections;

public class Laser1 : MonoBehaviour 
{
	public GameObject light1;
	public bool shootable = true;

	// Use this for initialization
	void Start () 
	{

	}
	
	// Update is called once per frame
	void FixedUpdate () 
	{
		ShootingLaser ();
	}

	void ShootingLaser()
	{
		if (shootable) 
		{
			StartCoroutine ("MakeLight");
		}
	}

	IEnumerator MakeLight()
	{	
		shootable = false;
		Instantiate (light1,transform.position,Quaternion.identity);	
		yield return new WaitForSeconds(15);
		shootable = true;
	}
}
