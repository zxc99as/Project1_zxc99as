﻿using UnityEngine;
using System.Collections;

public class Light1 : MonoBehaviour 
{
	public GameObject player;
	public GameObject laser;
	public float angle, angle2;
	public int time;
	public int time2;
	public int signx, signy;
	public bool stop;
	public bool shoot;


	// Use this for initialization
	void Start () 
	{
		player = GameObject.FindGameObjectWithTag ("Player");
		angle = Mathf.Atan2 (Mathf.Abs(transform.position.y - player.transform.position.y), Mathf.Abs(transform.position.x - player.transform.position.x));
		angle *= 57.295779513f;
		time = 0;
		time2 = 0;
		stop = false;
		shoot = true;
	}
	
	// Update is called once per frame
	void FixedUpdate () 
	{
		angle = Mathf.Atan2 (Mathf.Abs(transform.position.y - player.transform.position.y), Mathf.Abs(transform.position.x - player.transform.position.x));
		angle *= 57.295779513f;

		if (player.transform.position.x > transform.position.x) signx = 1;
		else signx = -1;

		if (player.transform.position.y > transform.position.y) signy = 1;
		else signy = -1;

		time ++;
		if(stop == false)
		{
			transform.position = 
				new Vector3 (((Mathf.Cos(angle * Mathf.Deg2Rad) / 50) * signx) + transform.position.x, 
				            ((Mathf.Sin (angle * Mathf.Deg2Rad) / 50) * signy) + transform.position.y, 0);
		
		}

		if (transform.position.x >= -10.8f) stop = true;

		if(stop && shoot)
		{
			angle2 = Mathf.Atan2 (Mathf.Abs(transform.position.y), Mathf.Abs(transform.position.x));
			angle2 *= 57.295779513f;
			laser.GetComponent<RedLaser>().angle2 = this.angle2;


			if(signy == 1)
			{
				laser.GetComponent<RedLaser>().angle = this.angle;
				laser.GetComponent<RedLaser>().currentx = this.transform.position.x;
				laser.GetComponent<RedLaser>().currenty = this.transform.position.y;
				laser.GetComponent<RedLaser>().signy = this.signy;
				laser.GetComponent<RedLaser>().delta = 0;


				Instantiate (laser, 
				             new Vector3(transform.position.x - (Mathf.Cos(angle * Mathf.Deg2Rad) * 37.36260613867404f / 2), transform.position.y - (Mathf.Sin(angle * Mathf.Deg2Rad) * 37.36260613867404f / 2), 0), 
				             Quaternion.Euler (0, 0, angle));
			}
			else if(signy == -1)
			{
				angle = 180 - angle;
				laser.GetComponent<RedLaser>().angle = this.angle;
				laser.GetComponent<RedLaser>().currentx = this.transform.position.x;
				laser.GetComponent<RedLaser>().currenty = this.transform.position.y;
				//laser.GetComponent<RedLaser>().signy = this.signy;
				laser.GetComponent<RedLaser>().delta = 180;

				Instantiate (laser, 
				             new Vector3(transform.position.x + (Mathf.Cos(angle * Mathf.Deg2Rad) * 37.36260613867404f / 2), transform.position.y + (Mathf.Sin(angle * Mathf.Deg2Rad) * 37.36260613867404f / 2), 0), 
				             Quaternion.Euler (0, 0, angle));
			}

			shoot = false;
		}

		if (time >= 473) Destroy (this.gameObject);
	}
}
