﻿using UnityEngine;
using System.Collections;

public class BulletPattern4 : MonoBehaviour 
{
	public GameObject bullet;
	public bool shootable = true;
	public int count;
	public float delta;

	// Use this for initialization
	void Start () 
	{
		count = 0;
		delta = 250;
	}
	
	// Update is called once per frame
	void FixedUpdate () 
	{
		ShootingBullet ();
	}
	
	void ShootingBullet()
	{
		if (shootable) 
		{
			StartCoroutine ("MakeBullet");
		}
	}
	
	IEnumerator MakeBullet()
	{	
		shootable = false;
		count++;
		
		for (int i = 0 ; i < 2; i++)
		{
			bullet.GetComponent<Pattern1>().angle = delta;
			bullet.GetComponent<Pattern1>().number = 3;
			Instantiate (bullet);
			
			delta += 80;
		}
		
		delta = 230;
		if(count == 10)
		{
			count = 0;
			yield return new WaitForSeconds(4.2f);
		}
		
		yield return new WaitForSeconds(0.1f);
		shootable = true;
	}
}
