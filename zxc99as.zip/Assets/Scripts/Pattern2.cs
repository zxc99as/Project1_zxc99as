﻿using UnityEngine;
using System.Collections;

public class Pattern2 : MonoBehaviour {

	public float x;
	public float y;
	public float angle = 0;
	public int r;
	public int count;
	public bool shoot;
	public GameObject player;
	
	// Use this for initialization
	void Start () 
	{
		x = 0;
		y = 0;
		r = 0;
		count = 0;
		shoot = false;
		player = GameObject.FindGameObjectWithTag ("Player");
	}
	
	// Update is called once per frame
	void FixedUpdate () 
	{

		x = Mathf.Cos(angle * Mathf.Deg2Rad) / 4;
		y = Mathf.Sin(angle * Mathf.Deg2Rad) / 4;
		
		transform.position = new Vector3 (transform.position.x - x, transform.position.y - y, transform.position.z);

		if (this.gameObject.name == "starBullet(Clone)") 
		{	
			transform.rotation = Quaternion.Euler (0,0, r += 10);		
		}

		if (this.gameObject.name == "specialBullet2(Clone)") 
		{	
			transform.rotation = Quaternion.Euler (0,0, r += 10);	

			if(this.gameObject.transform.position.x <= -10.55 && count != 2)
			{
				angle = Mathf.Atan2 (transform.position.y - player.transform.position.y, transform.position.x - player.transform.position.x);
				angle *= 57.295779513f;
				count++;
				shoot = true;
			}

			if(this.gameObject.transform.position.x >= 10.55 && count != 2)
			{
				angle = Mathf.Atan2 (transform.position.y - player.transform.position.y, transform.position.x - player.transform.position.x);
				angle *= 57.295779513f;
				count++;
				shoot = true;
			}

			if(this.gameObject.transform.position.y >= 4.05 && count != 2 && shoot)
			{
				angle = Mathf.Atan2 (transform.position.y - player.transform.position.y, transform.position.x - player.transform.position.x);
				angle *= 57.295779513f;
				count++;
			}

			if(this.gameObject.transform.position.y <= -24.18 && count != 2)
			{
				angle = Mathf.Atan2 (transform.position.y - player.transform.position.y, transform.position.x - player.transform.position.x);
				angle *= 57.295779513f;
				count++;
				shoot = true;
			}
		}


		if (transform.position.y <= -30)
			Destroy (this.gameObject);
		
		if (transform.position.y >= 17)
			Destroy (this.gameObject);
		
		if (transform.position.x <= -14)
			Destroy (this.gameObject);
		
		if (transform.position.x >= 14)
			Destroy (this.gameObject);
	}
}
