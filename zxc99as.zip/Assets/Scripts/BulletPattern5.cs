﻿using UnityEngine;
using System.Collections;

public class BulletPattern5 : MonoBehaviour {

	public GameObject bullet;
	public GameObject bullet2;
	public GameObject player;
	public bool shootable = true;
	public float delta, delta2;
	public float testAngle;
	public int count1, count2;
	public int[] map = {3,5,7,9,11,9,7,5};
	public int index;
	
	// Use this for initialization
	void Start () 
	{
		delta = 240;
		delta2 = 60;
		count1 = count2 = 0;
		index = 0;
		//testAngle = Mathf.Atan2 (transform.position.y - player.transform.position.y, transform.position.x - player.transform.position.x);
		//testAngle *= 57.295779513f;
		testAngle = 90;
		player = GameObject.FindGameObjectWithTag ("Player");
	}
	
	// Update is called once per frame
	void FixedUpdate () 
	{
		ShootingBullet ();
	}
	
	void ShootingBullet()
	{
		if (shootable) 
		{
			StartCoroutine ("MakeBullet");
		}
	}
	
	IEnumerator MakeBullet()
	{	
		shootable = false;
		
		for (int i = 0 ; i < 21; i++)
		{
			if(count1 < map[index])
			{
				bullet.GetComponent<Pattern1>().angle = delta;
				//bullet.GetComponent<Pattern1>().number = 3;
				Instantiate (bullet);
				count1++;
			}

			else if(count2 < 7)
			{
				count2++;
				delta += 3;
				continue;
			}

			else
			{
				bullet.GetComponent<Pattern1>().angle = delta;
				//bullet.GetComponent<Pattern1>().number = 3;
				Instantiate (bullet);
			}
			
			delta += 3;
		}
		if(60 > testAngle || testAngle > 120)
		{
			for (int i = 0; i < 30; i++) 
			{
				delta2 -= 2;
				bullet2.GetComponent<Pattern1>().angle = delta2;
				bullet2.GetComponent<Pattern1>().number = 4;
				Instantiate (bullet2);

			}

		}

		count1 = count2 = 0;
		index = (index + 1) % 8;
		delta = 240;
		testAngle = Mathf.Atan2 (transform.position.y - player.transform.position.y, transform.position.x - player.transform.position.x);
		testAngle *= 57.295779513f;
		
		yield return new WaitForSeconds(0.1f);
		shootable = true;
	}
}
