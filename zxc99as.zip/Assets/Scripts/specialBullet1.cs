﻿using UnityEngine;
using System.Collections;

public class specialBullet1 : MonoBehaviour 
{
	public GameObject bullet;
	public GameObject bullet2;
	public GameObject player;
	public bool shootable = true;
	public float angle;
	public int stage = 1;

	// Use this for initialization
	void Start () 
	{
		player = GameObject.FindGameObjectWithTag ("Player");
		angle = Mathf.Atan2 (transform.position.y - player.transform.position.y, transform.position.x - player.transform.position.x);
	}
	
	// Update is called once per frame
	void Update () 
	{
		if (shootable) 
		{
			StartCoroutine ("MakeBullet");
		}
	}

	IEnumerator MakeBullet()
	{	
		shootable = false;

		if(stage == 1)
		{
			angle = Mathf.Atan2 (transform.position.y - player.transform.position.y, transform.position.x - player.transform.position.x);
			angle *= 57.295779513f;
			bullet.GetComponent<Pattern2>().angle = this.angle;
			Instantiate (bullet,transform.position,Quaternion.identity);
		}

		if(stage == 2)
		{
			angle = Mathf.Atan2 (transform.position.y - player.transform.position.y, transform.position.x - player.transform.position.x);
			angle *= 57.295779513f;
			bullet2.GetComponent<Pattern2>().angle = this.angle;
			Instantiate (bullet2,transform.position,Quaternion.identity);
		}

		yield return new WaitForSeconds (1.5f);
		
		shootable = true;
		
	}
}
