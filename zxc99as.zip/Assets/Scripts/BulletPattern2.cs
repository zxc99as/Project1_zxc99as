﻿using UnityEngine;
using System.Collections;

public class BulletPattern2 : MonoBehaviour {

	public GameObject bullet;
	public GameObject player;
	public bool shootable = true;
	public float delta;
	public int count;
	public float time;
	public float angle;

	// Use this for initialization
	void Start () 
	{
		count = 0;
		player = GameObject.FindGameObjectWithTag ("Player");
		angle = Mathf.Atan2 (transform.position.y - player.transform.position.y, transform.position.x - player.transform.position.x);
		angle *= 57.295779513f;
		delta = angle;
	}
	
	// Update is called once per frame
	void FixedUpdate () 
	{
		ShootingBullet ();
	}
	
	void ShootingBullet()
	{
		if (shootable) 
		{
			StartCoroutine ("MakeBullet");
		}
	}
	
	IEnumerator MakeBullet()
	{	
		shootable = false;

		if (this.gameObject.name == "SubBullet1") 
		{
			for (int x = 0; x < 7; x++) 
			{
				bullet.GetComponent<Pattern2> ().angle = (this.angle - 9);
				Instantiate (bullet, transform.position, Quaternion.Euler (0, 0, angle - 9 - 90));
				angle += 3;
			}


		} 

		else if (this.gameObject.name == "SubBullet2") 
		{
			for (int x = 0; x < 7; x++) 
			{
				bullet.GetComponent<Pattern2> ().angle = (this.angle - 9);
				Instantiate (bullet, transform.position, Quaternion.Euler (0, 0, angle - 9 - 90));
				angle += 3;
			}
		}

		count++;
		angle = delta;


		if (count == 7) 
		{
			count = 0;
			angle = Mathf.Atan2 (transform.position.y - player.transform.position.y, transform.position.x - player.transform.position.x);
			angle *= 57.295779513f;
			delta = angle;
			yield return new WaitForSeconds (0.8f);
		}

		else
			yield return new WaitForSeconds (0.02f);

		shootable = true;

	}
}
