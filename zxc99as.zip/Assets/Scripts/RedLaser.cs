﻿using UnityEngine;
using System.Collections;

public class RedLaser : MonoBehaviour 
{
	public float x;
	public float y;
	public float angle, angle2;
	public float middle;
	public int delta;
	public float cutx, cuty;
	public float currentx, currenty;
	public float alpha;
	public int signy;
	public int timer;
	public int switchXY;
	public bool cutting, end;
	public GameObject CutAria;


	// Use this for initialization
	void Start () 
	{
		cutting = false;
		end = false;
		timer = 0;
	}
	
	// Update is called once per frame
	void FixedUpdate () 
	{
		x = (Mathf.Cos(angle * Mathf.Deg2Rad) / 7);
		y = (Mathf.Sin(angle * Mathf.Deg2Rad) / 7);
		timer ++;

		if(angle <= 90)
		{
			x *= -1;
			y *= -1;
		}

		transform.position = new Vector3 (transform.position.x - x, transform.position.y - y, transform.position.z);

		if(delta == 0)
		{
			if(angle2 >= angle)
			{
				signy = -1;
				switchXY = 1;
			}
			if(angle2 < angle)
			{
				signy = 1;
				switchXY = -1;
			}

			alpha = ((Mathf.Tan(angle * Mathf.Deg2Rad) * currentx) - currenty) * (-1);
			if(switchXY == 1) middle = (Mathf.Tan(angle * Mathf.Deg2Rad) * 10.8f) + alpha;
			else if(switchXY == -1) middle = 4.35f;
			middle = (middle + currenty) / 2;
		}

		if(delta == 180)
		{
			if(angle2 >= (delta - angle)) signy = -1;
			if(angle2 < (delta - angle)) signy = 1;

			alpha = ((Mathf.Tan((180 - angle) * Mathf.Deg2Rad) * currentx * (-1)) - currenty) * (-1);
			middle = (Mathf.Tan((180 - angle) * Mathf.Deg2Rad) * 10.8f * (-1)) + alpha; 
			middle = (middle + currenty) / 2;
		}

		//Debug.Log ("angle >> " + angle);
		//Debug.Log ("angle2 >> " + angle2);
		if(delta == 0)
		{
			if(signy == 1 && !cutting)
			{
				if(transform.position.y >= middle)
				{
					cutx = transform.position.x;
					cuty = transform.position.y;
					Instantiate (CutAria,new Vector3(cutx,cuty,0),Quaternion.Euler (0, 0, angle));
					cutting = true;
				}
			}
			
			if(signy == -1 && !cutting)
			{
				if(transform.position.y >= middle)
				{
					cutx = transform.position.x;
					cuty = transform.position.y;
					Instantiate (CutAria,new Vector3(cutx,cuty,0),Quaternion.Euler (0, 0, angle));
					cutting = true;
				}
			}
		}

		if(delta == 180)
		{
			if(signy == 1 && !cutting)
			{
				if(transform.position.y >= middle)
				{
					cutx = transform.position.x;
					cuty = transform.position.y;
					Instantiate (CutAria,new Vector3(cutx,cuty,0),Quaternion.Euler (0, 0, angle));
					cutting = true;
				}
			}

			if(signy == -1 && !cutting)
			{
				if(transform.position.y < middle)
				{
					cutx = transform.position.x;
					cuty = transform.position.y;
					Instantiate (CutAria,new Vector3(cutx,cuty,0),Quaternion.Euler (0, 0, angle));
					cutting = true;
				}
			}
		}

		if(cutting && !end && timer >= 5)
		{
			cuty += signy * 0.5f;
			Instantiate (CutAria,new Vector3(cutx,cuty,0),Quaternion.Euler (0, 0, angle));

			//if(cut >= 5 || cut <= -25) end = true;
			if(cuty - (Mathf.Sin(angle * Mathf.Deg2Rad) * 37.36260613867404f / 2) >= 5 || cuty + (Mathf.Sin(angle * Mathf.Deg2Rad) * 37.36260613867404f / 2) <= -25) end = true;

			timer = 0;
		}

		if (transform.position.x >= 32)	Destroy (this.gameObject);
	}
}
