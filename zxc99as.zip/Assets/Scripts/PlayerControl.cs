﻿using UnityEngine;
using System.Collections;

public class PlayerControl : MonoBehaviour 
{
	public int time;

	// Use this for initialization
	void Start () 
	{
		time = 0;
	}
	
	// Update is called once per frame
	void FixedUpdate () 
	{
		if(Input.GetKey(KeyCode.LeftArrow) && transform.position.x >= -10.15f)
			transform.position = new Vector3(transform.position.x - 0.2f,transform.position.y,transform.position.z);

		if(Input.GetKey(KeyCode.RightArrow) && transform.position.x <= 10)
			transform.position = new Vector3(transform.position.x + 0.2f,transform.position.y,transform.position.z);

		if(Input.GetKey(KeyCode.UpArrow) && transform.position.y <= 3.6f)
			transform.position = new Vector3(transform.position.x,transform.position.y + 0.2f,transform.position.z);

		if(Input.GetKey(KeyCode.DownArrow) && transform.position.y >= -23.8f)
			transform.position = new Vector3(transform.position.x,transform.position.y - 0.2f,transform.position.z);

		time += 1;
	}

	void OnCollisionEnter2D (Collision2D col)
	{
		if (col.gameObject.tag == "enemy")
			Destroy (this.gameObject);

		if (col.gameObject.tag == "Laser")
			Destroy (this.gameObject);

		if (col.gameObject.tag == "Block" && time >= 50)
		{
			Destroy (col.gameObject);
			time = 0;
		}
	}
}
