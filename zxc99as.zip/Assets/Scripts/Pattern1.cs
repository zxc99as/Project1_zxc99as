﻿using UnityEngine;
using System.Collections;

public class Pattern1 : MonoBehaviour 
{
	
	public float x, prex;
	public float y, prey;
	public float angle = 0;
	public int number;
	public int time, time2, count;
	public bool movable;
	public GameObject player;
	public GameObject bullet;

	// Use this for initialization
	void Start () 
	{
		x = y = 0;
		angle = angle % 360;
		time = count = 0;
		prex = prey = 100;
		movable = true;
		player = GameObject.FindGameObjectWithTag ("Player");
	}
	
	// Update is called once per frame
	void FixedUpdate () 
	{

		if(number == 2)
		{
			x = (Mathf.Cos(angle * Mathf.Deg2Rad) / 10);
			y = (Mathf.Sin(angle * Mathf.Deg2Rad) / 10);

			transform.position = new Vector3 (transform.position.x + x, transform.position.y + y, transform.position.z);
		}

		else if(number == 3)
		{
			if(count == 0)
			{
				x = (Mathf.Cos(angle * Mathf.Deg2Rad) / 7);
				y = (Mathf.Sin(angle * Mathf.Deg2Rad) / 7);
			
				transform.position = new Vector3 (transform.position.x + x, transform.position.y + y, transform.position.z);
			}

			else if(count != 0)
			{
				x = (Mathf.Cos(angle * Mathf.Deg2Rad) / 7);
				y = (Mathf.Sin(angle * Mathf.Deg2Rad) / 7);
				
				transform.position = new Vector3 (transform.position.x - x, transform.position.y - y, transform.position.z);
			}

			time++;

			if(time >= 100 && movable)
			{
				time = 0;
				angle = Mathf.Atan2 (transform.position.y - player.transform.position.y, transform.position.x - player.transform.position.x);
				angle *= 57.295779513f;

				count++;
				prex = player.transform.position.x;
				prey = player.transform.position.y;
				movable = false;
			}

			if(prex - 0.2f <= transform.position.x && transform.position.x <= prex + 0.2f && prey - 0.2f <= transform.position.y && transform.position.y <= prey + 0.2f) 
				Destroy(this.gameObject);
		}

		else if(number == 4 && this.gameObject.name == "bullet3(Clone)")
		{
			x = (Mathf.Cos(angle * Mathf.Deg2Rad) / 3);
			y = (Mathf.Sin(angle * Mathf.Deg2Rad) / 3);
			
			transform.position = new Vector3 (transform.position.x + x, transform.position.y + y, transform.position.z);
		}

		else if(number == 5)
		{
			time2++;
			if(time2 <= 75)
			{
				x = (Mathf.Cos(angle * Mathf.Deg2Rad) / 7);
				y = (Mathf.Sin(angle * Mathf.Deg2Rad) / 7);
			
				transform.position = new Vector3 (transform.position.x - x, transform.position.y - y, transform.position.z);
			}

			else
			{
				transform.localScale -= new Vector3(0.045f, 0.045f, 0);
				if(transform.localScale.x <= 0.8f)
				{
					float delta = angle/* / 57.295779513f*/;
					delta += 12;
					for(int i = 0 ; i < 15 ; i++)
					{
						bullet.GetComponent<Pattern1>().angle = delta;
						Instantiate(bullet, transform.position, Quaternion.identity);
						delta += 24;
						//delta *= 57.295779513f;
					}
					Destroy (this.gameObject);
				}
			}
		}

		else 
		{
			x = (Mathf.Cos(angle * Mathf.Deg2Rad) / 10);
			y = (Mathf.Sin(angle * Mathf.Deg2Rad) / 10);

			transform.position = new Vector3 (transform.position.x + x, transform.position.y + y, transform.position.z);
		}

		if (transform.position.y <= -30)
			Destroy (this.gameObject);

		if (transform.position.y >= 17)
			Destroy (this.gameObject);

		if (transform.position.x <= -14)
			Destroy (this.gameObject);

		if (transform.position.x >= 14)
			Destroy (this.gameObject);
	}
}
