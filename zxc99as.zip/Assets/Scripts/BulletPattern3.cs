﻿using UnityEngine;
using System.Collections;

public class BulletPattern3 : MonoBehaviour 
{
	public GameObject bullet;
	public bool shootable = true;
	public float delta;
	public int count, x, alpha;
	public float time;

	// Use this for initialization
	void Start () 
	{
		delta = 200;
		count = 0;
		x = 0;
		alpha = 0;
	}
	
	// Update is called once per frame
	void FixedUpdate () 
	{
		ShootingBullet ();
	}
	
	void ShootingBullet()
	{
		if (shootable) 
		{
			StartCoroutine ("MakeBullet");
		}
	}
	
	IEnumerator MakeBullet()
	{	
		shootable = false;
		count++;
		time = 0.07f;

		for (int i = 0 ; i < (8 + alpha); i++)
		{
			bullet.GetComponent<Pattern1>().angle = delta;
			bullet.GetComponent<Pattern1>().number = 2;
			Instantiate (bullet);

			delta += 20;
		}

		delta = 200 + x;

		if(count == 3)
		{
			if(x == 0)
			{
				x = 10;
				alpha = -1;
			}
			else if(x == 10)
			{
				x = 0;
				alpha = 0;
			}

			delta = 200 + x;
			count = 0;
			time = 0.15f;
		}

		yield return new WaitForSeconds(time);
		shootable = true;
	}
}
