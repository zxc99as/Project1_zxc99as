﻿using UnityEngine;
using System.Collections;

public class StageManage : MonoBehaviour 
{
	public GameObject MainBullet;
	public GameObject SubBullet1;
	public GameObject SubBullet2;
	public GameObject special1;
	public GameObject spacial2;
	public GameObject L1;

	public int Stage;
	public int time;

	// Use this for initialization
	void Start () 
	{
		Stage = 1;
		time = 0;
	}
	
	// Update is called once per frame
	void FixedUpdate () 
	{
		if(Stage == 1)
		{
			time++;
			MainBullet.GetComponent<BulletPattern1>().enabled = true;

			if(time >= 2000)
			{
				Stage++;
				MainBullet.GetComponent<BulletPattern1>().enabled = false;
				time = 0;
			}
		}

		else if(time >= 400 && Stage == 2)
		{

		}

		else
		{
			time++;
		}
	}
}
